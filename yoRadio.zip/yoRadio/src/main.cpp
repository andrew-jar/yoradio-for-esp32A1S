#include "Arduino.h"
#include "core/options.h"
#include "core/config.h"
#include "core/telnet.h"
#include "core/player.h"
#include "core/display.h"
#include "core/network.h"
#include "core/netserver.h"
#include "core/controls.h"
#include "core/mqtt.h"
#include "core/optionschecker.h"

//++++++++ Add for Audio Kit 2.3 A247 with ES8388 codec
#include "ES8388.h"  // https://github.com/maditnerd/es8388

#define I2S_DOUT      26
#define I2S_BCLK      27
#define I2S_LRC       25
#define I2S_DSIN      35
#define I2S_MCLK      0

// GPIOs for SPI  ES8388
#define ES_SPI_MOSI      23
#define ES_SPI_MISO      19
#define ES_SPI_SCK       18
#define ES_SPI_CS        5 

// I2C GPIOs for ES8388
#define ES_IIC_CLK       32
#define ES_IIC_DATA      33
// Amplifier enable
#define GPIO_PA_EN    21



ES8388 es;

int es_volume = 85;   // 0...100

//-------- for Audio Kit 2.3 A247 with ES8388 codec

extern __attribute__((weak)) void yoradio_on_setup();



#if DSP_HSPI || TS_HSPI || VS_HSPI
SPIClass  SPI2(HOOPSENb);
#endif

extern __attribute__((weak)) void yoradio_on_setup();

void setup() {
  Serial.begin(115200);
  pinMode(GPIO_PA_EN, OUTPUT);
  digitalWrite(GPIO_PA_EN, HIGH);
  if(REAL_LEDBUILTIN!=255) pinMode(REAL_LEDBUILTIN, OUTPUT);
  if (yoradio_on_setup) yoradio_on_setup();
  pm.on_setup();
  config.init();
  display.init();
  player.init();
  network.begin();
  if (network.status != CONNECTED && network.status!=SDREADY) {
    netserver.begin();
    initControls();
    display.putRequest(DSP_START);
    while(!display.ready()) delay(10);
    return;
  }
  if(SDC_CS!=255) {
    display.putRequest(WAITFORSD, 0);
    Serial.print("##[BOOT]#\tSD search\t");
  }
  config.initPlaylistMode();
  netserver.begin();
  telnet.begin();
  initControls();
  display.putRequest(DSP_START);
  while(!display.ready()) delay(10);
  #ifdef MQTT_ROOT_TOPIC
    mqttInit();
  #endif
  if (config.getMode()==PM_SDCARD) player.initHeaders(config.station.url);
  player.lockOutput=false;
  if (config.store.smartstart == 1) player.sendCommand({PR_PLAY, config.lastStation()});
  pm.on_end_setup();

//++++++++ Add for Audio Kit 2.3 A247 with ES8388 codec
    SPI.begin(ES_SPI_SCK, ES_SPI_MISO, ES_SPI_MOSI, ES_SPI_CS);  
    SPI.setFrequency(1000000);

    Serial.printf("Connect to ES8388 codec... ");
    while (not es.begin( ES_IIC_DATA, ES_IIC_CLK))
    {
        Serial.printf("Failed!\n");
        delay(1000);
    }
    Serial.printf("OK\n");

    es.volume(ES8388::ES_MAIN, es_volume);
    es.volume(ES8388::ES_OUT1, es_volume);
    es.volume(ES8388::ES_OUT2, es_volume);
    es.mute(ES8388::ES_OUT1, false);
    es.mute(ES8388::ES_OUT2, false);
    es.mute(ES8388::ES_MAIN, false);
//-------- for Audio Kit 2.3 A247 with ES8388 codec


}

void loop() {
  telnet.loop();
  if (network.status == CONNECTED || network.status==SDREADY) {
    player.loop();
    //loopControls();
  }
  loopControls();
  netserver.loop();
}

#include "core/audiohandlers.h"
